using Vintagestory.API.Common;
namespace Compass {
  class BlockRelativeCompass : BlockCompass {
  }
}