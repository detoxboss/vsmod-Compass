using System;
using Vintagestory.API.MathTools;
using Vintagestory.API.Common;

namespace Compass {
  class BlockMagneticCompass : BlockCompass {
    public override float GetNeedle2DAngleRadians(BlockPos fromPos, ItemStack compass) {
      return 0.0f;
    }

    public override BlockPos GetTargetPos(ItemStack compassStack) {
      return null;
    }

    public override void SetTargetPos(ItemStack compassStack, BlockPos targetPos) {
      return;
    }
  }
}